# Kebapçı Ömer Yönetim – İlk sürüm prototipi

## İçerik
- Restoran, Trendyol ve Yemeksepeti ciro girişi
- Restoran için nakit, kart, havale ve veresiye ayrımı
- Gider kaydı
- Vergi, SGK, banka kredisi, şahsi ve işletme borçları
- Ayrı toptancı cari hesapları, alış ve ödeme hareketleri
- Personel listesi, maaş ve avans hareketleri
- Tarih aralığına göre temel ciro/gider raporu
- JSON yedek alma ve geri yükleme

## Önemli sınırlar
Bu, tarayıcıda çalışan ilk arayüz prototipidir. Veriler yalnızca kullanılan cihazın/tarayıcının localStorage alanında tutulur. Henüz:
- kullanıcı hesabı ve rol bazlı erişim,
- personel ile işletme sahibinin ortak veri görmesi,
- bulut veritabanı ve otomatik yedekleme,
- gerçek zamanlı iPhone bildirimleri,
- banka/POS/platform entegrasyonları
bulunmaz. Hassas mali kayıtları bu prototipe girmeden önce bu sınırları dikkate alın.

## iPhone'da kullanım
Dosyayı web sunucusuna HTTPS üzerinden yayınlamak gerekir. Yayınlandıktan sonra iPhone Safari'de adresi açıp Paylaş > Ana Ekrana Ekle seçilebilir. Sadece HTML dosyasını telefona indirmek, çok kullanıcılı çevrim içi uygulama kurmaz.

## Sonraki üretim aşaması
Ortak kullanım için kimlik doğrulama, yetki kontrolü, bulut veritabanı, denetim kayıtları, günlük yedekleme ve vade bildirimleri kurulmalıdır. Personel yetkileri en az ayrı ayrı tanımlanmalıdır.
